
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function LumiXChatbot() {
  const [messages, setMessages] = useState([
    {
      sender: "LumiX AI Beta 1.0",
      text: "Hello, I’m LumiX AI Beta 1.0, your assistant from Lumonix Labs. How can I help you today?"
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMessage = { sender: "You", text: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            { role: "system", content: "You are LumiX AI Beta 1.0, an empathetic and knowledgeable AI assistant developed by Lumonix Labs. Always speak clearly and professionally." },
            ...messages.map((m) => ({ role: m.sender === "You" ? "user" : "assistant", content: m.text })),
            { role: "user", content: input }
          ]
        })
      });
      const data = await response.json();
      setMessages((prev) => [...prev, { sender: "LumiX AI Beta 1.0", text: data.reply }]);
    } catch (error) {
      setMessages((prev) => [...prev, { sender: "LumiX AI Beta 1.0", text: "Sorry, something went wrong." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4 text-center text-blue-700">LumiX AI Beta 1.0</h1>
      <Card className="space-y-4 max-h-[70vh] overflow-y-auto p-4 bg-white shadow-md rounded-2xl">
        {messages.map((msg, idx) => (
          <CardContent key={idx} className={msg.sender === "You" ? "text-right" : "text-left text-blue-700"}>
            <p className="text-sm font-medium">{msg.sender}</p>
            <p className="text-base">{msg.text}</p>
          </CardContent>
        ))}
      </Card>
      <div className="flex items-center mt-4 gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          className="flex-grow"
        />
        <Button onClick={sendMessage} disabled={loading} className="bg-blue-600 text-white">
          {loading ? "..." : "Send"}
        </Button>
      </div>
    </div>
  );
}
